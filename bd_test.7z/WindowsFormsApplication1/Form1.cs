﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using System.IO;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Drawing.Printing;
using PdfSharp;
using PdfSharp.Pdf.Security;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private DataSet ds = new DataSet();
        private DataTable dt = new DataTable();
        private DataTable dt2 = new DataTable();
        private NpgsqlDataAdapter da;
        private NpgsqlDataAdapter da2;
        private NpgsqlCommandBuilder cb1;
        private NpgsqlConnection conn;
        private String sort;
        private String select;
        private String connstring;
        private String tableName;
        private ComboBox[] Boxes1;
        private ComboBox[] Boxes2;
        private int currentComboBox = 0;
        private int currentComboBox2 = 0;
        private Label[] labWhere;
        private TextBox[] minWhere;
        private TextBox[] maxWhere;
        private string where;
        private Label[] labWhere2;
        private TextBox[] minWhere2;
        private TextBox[] maxWhere2;
        private string where2;


        public Form1()
        {
            InitializeComponent();
            panel1.Visible = false;
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
        }
        private void updateTable()
        {
            try
            {
                select = "";
                for (int i=0; i<checkedListBox1.CheckedItems.Count; i++)
                {
                    if (select=="") select += checkedListBox1.CheckedItems[i];
                    else select += ", "+ checkedListBox1.CheckedItems[i];

                }

                if (select != "")
                {
                    string sql = "SELECT " + select + " FROM " + tableName + " " + where + " " + sort;
                    da = new NpgsqlDataAdapter(sql, conn);

                    ds.Reset();
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;

                    int colum = Convert.ToInt32(dataGridView1.ColumnCount);
                    int row = Convert.ToInt32(dataGridView1.RowCount - 1);
                    if (checkBox2.Checked == true)
                    {

                        for (int i = 0; i < row; i++)
                        {
                            bool full = true;
                            for (int i2 = 0; i2 < colum; i2++)
                            {
                                if (dataGridView1.Rows[i].Cells[i2].Value == System.DBNull.Value)
                                    full = false;
                            }
                            if (full == true)
                            {
                                dataGridView1.Rows.Remove(dataGridView1.Rows[i]);
                                row--;
                                i--;
                            }
                        }
                    }
                    if (checkBox1.Checked==true)
                    {
                        colum = Convert.ToInt32(dataGridView1.ColumnCount);
                        row = Convert.ToInt32(dataGridView1.RowCount - 1);

                        if (checkBox1.Checked == true)
                            for (int i = 0; i <= row - 1; i++)
                            {
                                for (int i2 = 0; i2 <= colum - 1; i2++)
                                {
                                    if (dataGridView1.Rows[i].Cells[i2].Value == System.DBNull.Value)
                                        dataGridView1.Rows[i].Cells[i2].Style.BackColor = Color.Red;
                                }
                            }
                        else
                            for (int i = 0; i <= row - 1; i++)
                            {
                                for (int i2 = 0; i2 <= colum - 1; i2++)
                                {
                                    if (dataGridView1.Rows[i].Cells[i2].Style.BackColor == Color.Red)
                                        dataGridView1.Rows[i].Cells[i2].Style.BackColor = Color.White;
                                }
                            }
                    }
                }
                else
                {
                    dataGridView1.DataSource = null;
                }
            }
            catch (Exception msg)
            {
               
                MessageBox.Show(msg.ToString());
            }

            dataGridView1.RowsDefaultCellStyle = dataGridView1.ColumnHeadersDefaultCellStyle;

            for (int i = 0; i<dataGridView1.Rows.Count;i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString() ;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveTable();
        }

        private void CheckTable(object sender, EventArgs e)
        {
            updateTable();
        }

        private void comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            saveTable();
            for (currentComboBox = 0; currentComboBox < Boxes1.Length; currentComboBox++)
            {
                if (Boxes1[currentComboBox] == sender)
                {
                    cleareBoxes(currentComboBox + 1);
                    break;
                }
            }
            if (Boxes1[currentComboBox].Items.Count > 3 && Boxes1[currentComboBox].SelectedItem.ToString()!="")
            {
                currentComboBox++;
                Boxes1[currentComboBox] = new ComboBox();
                Boxes1[currentComboBox].Name = currentComboBox.ToString();
                Boxes1[currentComboBox].Location = new Point(Boxes1[currentComboBox - 1].Location.X, Boxes1[currentComboBox - 1].Location.Y + 25);
                Boxes1[currentComboBox].SelectedIndexChanged += new EventHandler(comboBox_SelectedIndexChanged);
                Boxes1[currentComboBox].Anchor=(AnchorStyles.Top | AnchorStyles.Right);
                Boxes1[currentComboBox].DropDownStyle = ComboBoxStyle.DropDownList;
                for (int i = 0; i < Boxes1[currentComboBox - 1].Items.Count; i++)
                {
                    if (Boxes1[currentComboBox - 1].Items[i] != Boxes1[currentComboBox - 1].SelectedItem)
                        Boxes1[currentComboBox].Items.Add(Boxes1[currentComboBox - 1].Items[i]);
                }
                panel1.Controls.Add(Boxes1[currentComboBox]);
            }
            sort = "";
            if (Boxes1[0].SelectedItem.ToString()!="")
            {
                sort = "ORDER BY " + Boxes1[0].SelectedItem.ToString();
                for (int i =1; i<Boxes1.Length; i++)
                {
                    if (Boxes1[i] != null)
                    {
                        if (Boxes1[i].SelectedItem != null && Boxes1[i].SelectedItem.ToString() != "")
                        {
                            sort += ", " + Boxes1[i].SelectedItem.ToString();
                        }
                        else
                            break;
                    }
                }
            }
            updateTable();
        }

        private void cleareBoxes(int a)
        {
            for (int i = a; i < Boxes1.Length; i++)
            {
                panel1.Controls.Remove(Boxes1[i]);
            }
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            saveTable();
           updateTable();
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            updateTable();
        }

        //кнопка подключения к базе по введеным параметрам
        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox5.Text==textBox8.Text && textBox7.Text==textBox6.Text && conn2!=null)
            {
                MessageBox.Show("Эта таблица уже открыта");
            }
            else
            {
                connstring = String.Format("Server=" + textBox1.Text + ";Port=" + textBox2.Text + ";User Id=" + textBox3.Text + ";Password=" + textBox4.Text + ";Database=" + textBox5.Text + ";");
                tableName = Convert.ToString(textBox6.Text);
                panel2.Visible = false;
                panel1.Visible = true;
                conect();
            }
        }

        //подключение базы данных
        private void conect ()
        {
            try
            {
                conn = new NpgsqlConnection(connstring);
                conn.Open();

                string sql = "SELECT * FROM " + tableName;
                da = new NpgsqlDataAdapter(sql, conn);

                ds.Reset();
                da.Fill(ds);
                dt = ds.Tables[0];
                dataGridView1.DataSource = dt;

                string sqlSelect = "SELECT column_name, data_type FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '" + tableName + "' ";
                da2 = new NpgsqlDataAdapter(sqlSelect, conn);
                da2.Fill(dt2);
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    checkedListBox1.Items.Add(Convert.ToString(dt2.Rows[i][0]), true);
                    comboBox1.Items.Add(Convert.ToString(dt2.Rows[i][0]));
                }

                Boxes1 = new ComboBox[comboBox1.Items.Count];
                Boxes1[0] = comboBox1;

                int count = 0;
                for (int i = 0; i < dt2.Rows.Count; i++)
                {
                    if (dt2.Rows[i][1].ToString() == "integer") count++;
                }
                if (count != 0)
                { 
                labWhere = new Label[count];
                minWhere = new TextBox[count];
                maxWhere = new TextBox[count];
                count = 0;
                    for (int i = 0; i < dt2.Rows.Count; i++)
                    {
                        if (dt2.Rows[i][1].ToString() == "integer")
                        {
                            count++;
                            if (count == 1)
                            {
                                Label lab = new Label();
                                lab.Text = dt2.Rows[i][0].ToString();
                                lab.Location = new Point(545, 7);
                                lab.Name = "lab1";
                                lab.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                
                                panel1.Controls.Add(lab);
                                labWhere[count - 1] = lab;

                                TextBox min = new TextBox();
                                min.Location = new Point(505, lab.Location.Y+24);
                                min.Name = "min1";
                                min.Size = new System.Drawing.Size(50, 30);
                                min.TextChanged += new EventHandler(Where);
                                min.KeyPress += new KeyPressEventHandler(onlyNumbers);
                                min.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                panel1.Controls.Add(min);
                                minWhere[count - 1] = min;

                                TextBox max = new TextBox();
                                max.Location = new Point(565, lab.Location.Y + 24);
                                max.Name = "max1";
                                max.Size = new System.Drawing.Size(50, 30);
                                max.TextChanged += new EventHandler(Where);
                                max.KeyPress += new KeyPressEventHandler(onlyNumbers);
                                max.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                panel1.Controls.Add(max);
                                maxWhere[count - 1] = max;
                            }
                            else
                            {
                                Label lab = new Label();
                                lab.Text = dt2.Rows[i][0].ToString();
                                lab.Location = new Point(545, labWhere[count-2].Location.Y+50);
                                lab.Name = "lab" + count.ToString();
                                lab.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                panel1.Controls.Add(lab);
                                labWhere[count - 1] = lab;

                                TextBox min = new TextBox();
                                min.Location = new Point(505, lab.Location.Y + 24);
                                min.Size = new System.Drawing.Size(50, 30);
                                min.TextChanged += new EventHandler(Where);
                                min.KeyPress += new KeyPressEventHandler(onlyNumbers);
                                min.Name = "min" + count.ToString();
                                min.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                panel1.Controls.Add(min);
                                minWhere[count - 1] = min;

                                TextBox max = new TextBox();
                                max.Location = new Point(565, lab.Location.Y + 24);
                                max.Name = "max" + count.ToString();
                                max.Size = new System.Drawing.Size(50, 30);
                                max.TextChanged += new EventHandler(Where);
                                max.KeyPress += new KeyPressEventHandler(onlyNumbers);
                                max.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                                panel1.Controls.Add(max);
                                maxWhere[count - 1] = max;
                            }
                        }
                    }
                }
            }
            catch
            {
                panel1.Visible = false;
                panel2.Visible = true;
                MessageBox.Show("невозможно подключиться к базе данных");
            }
            try
            {
                String pkInstalledPrinters;
                for (int i = 0; i < PrinterSettings.InstalledPrinters.Count; i++)
                {
                    pkInstalledPrinters = PrinterSettings.InstalledPrinters[i];
                    printers.Items.Add(pkInstalledPrinters);
                }
            }
            catch
            {
                MessageBox.Show("Невозможно обноружить принтеры. Печать будет недоступна.");
                print.Visible = false;
            }
        }

        //проверка на введение в поле только чисел
        private void onlyNumbers(object sender, KeyPressEventArgs e)
        {
            if (char.IsNumber(e.KeyChar))
            {
                
            }
            else
            {
                e.Handled = e.KeyChar != (char)Keys.Back;
            }
        }

        private void Where(object sender, EventArgs e)
        {
            where = "";
            for (int i=0;i<labWhere.Length; i++)
            {
                if (minWhere[i].Text!="")
                {
                    if(where=="")
                    {
                        where = "WHERE " + labWhere[i].Text + ">=" + minWhere[i].Text;
                    }
                    else
                    {
                        where +="AND " + labWhere[i].Text + ">=" + minWhere[i].Text;
                    }
                }
                if (maxWhere[i].Text != "")
                {
                    if (where == "")
                    {
                        where = "WHERE " + labWhere[i].Text + "<=" + maxWhere[i].Text;
                    }
                    else
                    {
                        where += "AND " + labWhere[i].Text + "<=" + maxWhere[i].Text;
                    }
                }
            }
            updateTable();
        }

        //Прекратить работу с текущей баззой даных
        private void button1_Click(object sender, EventArgs e)
        {
            closeCon();
        }

        private void closeCon ()
        {
            dt2.Clear();
            conn.Close();
            for (int i = checkedListBox1.Items.Count - 1; i >= 0; i--)
                checkedListBox1.Items.RemoveAt(i);
            for (int i = comboBox1.Items.Count - 1; i >= 0; i--)
                comboBox1.Items.RemoveAt(i);
            panel1.Visible = false;
            panel2.Visible = true;
            conn = null;
        }

        //функция сохранения
        private void saveTable()
        {
            try
            {
                if (checkedListBox1.CheckedItems.Count==checkedListBox1.Items.Count)
                {
                    if (checkBox2.Checked == false)
                    {


                        cb1 = new NpgsqlCommandBuilder(da);
                        da.Update(ds);
                    }
                    else
                    {
                        checkBox2.Checked = false;
                        cb1 = new NpgsqlCommandBuilder(da); 
                        da.Update(ds);
                        checkBox2.Checked = true;
                    }
                }
                else
                {
                    string sql = "SELECT * FROM " + tableName;
                    da = new NpgsqlDataAdapter(sql, conn);
                    ds.Reset();
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;

                    if (checkBox2.Checked == false)
                    {
                        cb1 = new NpgsqlCommandBuilder(da);
                        da.Update(ds);
                    }
                    else
                    {
                        checkBox2.Checked = false;
                        cb1 = new NpgsqlCommandBuilder(da);
                        da.Update(ds);
                        checkBox2.Checked = true;
                    }
                    updateTable();
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Изменения в базе данных выполнить не удалось!",
                  "Уведомление о результатах", MessageBoxButtons.OK);
            }
            
        }

        private string name;

        //составление отчета
        private void button7_Click(object sender, EventArgs e)
        {
            name = @"..\" + log.Text + "_" + textBox5.Text + "_" + textBox6.Text + "_" + DateTime.Now.ToString(@"dd_MM_yyyy__hh_mm_ss tt");
            iTextSharp.text.Document doc = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4.Rotate());
            PdfWriter.GetInstance(doc, new FileStream(name + "_log.pdf", FileMode.Create, FileAccess.Write, FileShare.None));    
            doc.Open();
            BaseFont baseFont = BaseFont.CreateFont("C:\\Windows\\Fonts\\arial.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(baseFont, iTextSharp.text.Font.DEFAULTSIZE, iTextSharp.text.Font.NORMAL);
            doc.Add(new Paragraph("В таблице " + textBox6.Text + " из базы данных " + textBox5.Text, font));

                if (checkedListBox1.CheckedItems.Count == checkedListBox1.Items.Count)
                {
                    
                    if (checkBox2.Checked == false)
                    {
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            string text="В колонке "+dataGridView1.Columns[i].Name;
                            string hollows=" ";
                            bool full = true;
                            int count = 0;
                            for (int i2 = 0; i2<dataGridView1.Rows.Count-1; i2++)
                            {
                                if(dataGridView1.Rows[i2].Cells[i].FormattedValue.ToString() =="")
                                {
                                    full = false;
                                    if (count==0)
                                         hollows += Convert.ToString(i2+1);
                                    else
                                         hollows +=", "+Convert.ToString(i2+1);
                                    count++;
                                }
                            }
                            if (full)
                            {
                                text += " все строки заполнены";
                            }
                            else
                            {
                                if (count == 1)
                                {
                                    text += " строка "+hollows+" не заполнена";
                                }
                                else
                                {
                                    text +=" строки "+hollows+" не заполнены";
                                }
                            }
                            doc.Add(new Paragraph(text,font));
                        }
                    }
                    else
                    {
                        checkBox2.Checked = false;
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            string text = "В колонке " + dataGridView1.Columns[i].Name;
                            string hollows = " ";
                            bool full = true;
                            int count = 0;
                            for (int i2 = 0; i2 < dataGridView1.Rows.Count - 1; i2++)
                            {
                                if (dataGridView1.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                                {
                                    full = false;
                                    if (count == 0)
                                        hollows += Convert.ToString(i2 + 1);
                                    else
                                        hollows += ", " + Convert.ToString(i2 + 1);
                                    count++;
                                }
                            }
                            if (full)
                            {
                                text += " все строки заполнены";
                            }
                            else
                            {
                                if (count == 1)
                                {
                                    text += " строка " + hollows + " не заполнена";
                                }
                                else
                                {
                                    text += " строки " + hollows + " не заполнены";
                                }
                            }
                            doc.Add(new Paragraph(text,font));
                        }
                        checkBox2.Checked = true;
                    }
                }
                else
                {
                    string sql = "SELECT * FROM " + tableName;
                    da = new NpgsqlDataAdapter(sql, conn);
                    ds.Reset();
                    da.Fill(ds);
                    dt = ds.Tables[0];
                    dataGridView1.DataSource = dt;

                    if (checkBox2.Checked == false)
                    {
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            string text = "В колонке " + dataGridView1.Columns[i].Name;
                            string hollows = " ";
                            bool full = true;
                            int count = 0;
                            for (int i2 = 0; i2 < dataGridView1.Rows.Count - 1; i2++)
                            {
                                if (dataGridView1.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                                {
                                    full = false;
                                    if (count == 0)
                                        hollows += Convert.ToString(i2 + 1);
                                    else
                                        hollows += ", " + Convert.ToString(i2 + 1);
                                    count++;
                                }
                            }
                            if (full)
                            {
                                text += " все строки заполнены";
                            }
                            else
                            {
                                if (count == 1)
                                {
                                    text += " строка " + hollows + " не заполнена";
                                }
                                else
                                {
                                    text += " строки " + hollows + " не заполнены";
                                }
                            }
                            doc.Add(new Paragraph(text,font));
                        }
                    }
                    else
                    {
                        checkBox2.Checked = false;
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            string text = "В колонке " + dataGridView1.Columns[i].Name;
                            string hollows = " ";
                            bool full = true;
                            int count = 0;
                            for (int i2 = 0; i2 < dataGridView1.Rows.Count - 1; i2++)
                            {
                                if (dataGridView1.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                                {
                                    full = false;
                                    if (count == 0)
                                        hollows += Convert.ToString(i2 + 1);
                                    else
                                        hollows += ", " + Convert.ToString(i2 + 1);
                                    count++;
                                }
                            }
                            if (full)
                            {
                                text += " все строки заполнены";
                            }
                            else
                            {
                                if (count == 1)
                                {
                                    text += " строка " + hollows + " не заполнена";
                                }
                                else
                                {
                                    text += " строки " + hollows + " не заполнены";
                                }
                            }
                            doc.Add(new Paragraph(text,font));
                        }
                        checkBox2.Checked = true;
                    }
                    updateTable();
                }
            doc.Close();  

            //печать документа
            if (print.Checked==true)
            {
                if (printers.SelectedItem != null)
                {
                    PrintDocument PD = new PrintDocument();
                    string PrinterName = printers.SelectedItem.ToString();
                    PrinterSettings PS = new PrinterSettings();
                    PS.PrinterName = PrinterName;
                    PD.PrinterSettings = PS;
                    PD.PrintPage += new PrintPageEventHandler(PD_PrintPage);
                    PD.Print();
                }
            }

            if (protect.Checked==true)
            {
                using (Stream output = new FileStream(name + "_log_pass.pdf", FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    PdfReader reader = new PdfReader(name + "_log.pdf");
                    PdfEncryptor.Encrypt(reader, output, true, pass.Text, "secret", PdfWriter.ALLOW_SCREENREADERS);
                    reader.Close();
                    File.Delete(name + "_log.pdf");

                }
            }

        }

        private void PD_PrintPage(object sender, PrintPageEventArgs e)
        {
            PdfReader reader = new PdfReader(name+"_log.pdf");

            String text="";

            for (int page = 1; page <= reader.NumberOfPages; page++)
            {
               ITextExtractionStrategy its = new iTextSharp.text.pdf.parser.LocationTextExtractionStrategy();
                String s = PdfTextExtractor.GetTextFromPage(reader, page, its);

                s = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(s)));
                text = text + s;

            }
            reader.Close();

            System.Drawing.Font PrintFont = new System.Drawing.Font("Arial", 3, FontStyle.Regular, GraphicsUnit.Millimeter);
            e.Graphics.DrawString(text, PrintFont, Brushes.Black, new PointF(0, 0));
        }

        private void print_CheckedChanged(object sender, EventArgs e)
        {
            if (print.Checked == true)
                printers.Visible = true;
            else
                printers.Visible = false;
        }


        private DataSet ds2 = new DataSet();
        private DataTable dt21 = new DataTable();
        private DataTable dt22 = new DataTable();
        private NpgsqlDataAdapter da21;
        private NpgsqlDataAdapter da22;
        private NpgsqlCommandBuilder cb12;
        NpgsqlConnection conn2;
        private String sort2;
        private String select2;
        private string connstring2;
        private string tableName2;


        private void updateTable2()
        {
            try
            {
                select2 = "";
                for (int i = 0; i < checkedListBox2.CheckedItems.Count; i++)
                {
                    if (select2 == "") select2 += checkedListBox2.CheckedItems[i];
                    else select2 += ", " + checkedListBox2.CheckedItems[i];

                }

                if (select2 != "")
                {
                    string sql2 = "SELECT " + select2 + " FROM " + tableName2 + " "+ where2 + " " + sort2;
                    da21 = new NpgsqlDataAdapter(sql2, conn2);

                    ds2.Reset();
                    da21.Fill(ds2);
                    dt21 = ds2.Tables[0];
                    dataGridView2.DataSource = dt21;

                    int colum2 = Convert.ToInt32(dataGridView2.ColumnCount);
                    int row2 = Convert.ToInt32(dataGridView2.RowCount - 1);
                    if (checkBox3.Checked == true)
                    {

                        for (int i = 0; i < row2; i++)
                        {
                            bool full = true;
                            for (int i2 = 0; i2 < colum2; i2++)
                            {
                                if (dataGridView2.Rows[i].Cells[i2].Value == System.DBNull.Value)
                                    full = false;
                            }
                            if (full == true)
                            {
                                dataGridView2.Rows.Remove(dataGridView2.Rows[i]);
                                row2--;
                                i--;
                            }
                        }
                    }
                    if (checkBox4.Checked==true)
                    {
                        colum2 = Convert.ToInt32(dataGridView2.ColumnCount);
                        row2 = Convert.ToInt32(dataGridView2.RowCount - 1);

                        if (checkBox4.Checked == true)
                            for (int i = 0; i <= row2 - 1; i++)
                            {
                                for (int i2 = 0; i2 <= colum2 - 1; i2++)
                                {
                                    if (dataGridView2.Rows[i].Cells[i2].Value == System.DBNull.Value)
                                        dataGridView2.Rows[i].Cells[i2].Style.BackColor = Color.Red;
                                }
                            }
                        else
                            for (int i = 0; i <= row2 - 1; i++)
                            {
                                for (int i2 = 0; i2 <= colum2 - 1; i2++)
                                {
                                    if (dataGridView2.Rows[i].Cells[i2].Style.BackColor == Color.Red)
                                        dataGridView2.Rows[i].Cells[i2].Style.BackColor = Color.White;
                                }
                            }
                    }
                }
                else
                {
                    dataGridView2.DataSource = null;
                }
            }
            catch (Exception msg)
            {

                MessageBox.Show(msg.ToString());
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            saveTable2();
        }

        private void CheckTable2(object sender, EventArgs e)
        {
            updateTable2();
        }

        private void comboBox_SelectedIndexChanged2(object sender, EventArgs e)
        {
            saveTable2();
            for (currentComboBox2 = 0; currentComboBox2 < Boxes2.Length; currentComboBox2++)
            {
                if (Boxes2[currentComboBox2] == sender)
                {
                    cleareBoxes2(currentComboBox2 + 1);
                    break;
                }
            }
            if (Boxes2[currentComboBox2].Items.Count > 3 && Boxes2[currentComboBox2].SelectedItem.ToString() != "")
            {
                currentComboBox2++;
                Boxes2[currentComboBox2] = new ComboBox();
                Boxes2[currentComboBox2].Name = currentComboBox2.ToString();
                Boxes2[currentComboBox2].Location = new Point(Boxes2[currentComboBox2 - 1].Location.X, Boxes2[currentComboBox2 - 1].Location.Y + 25);
                Boxes2[currentComboBox2].SelectedIndexChanged += new EventHandler(comboBox_SelectedIndexChanged2);
                Boxes2[currentComboBox2].Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                Boxes2[currentComboBox2].DropDownStyle = ComboBoxStyle.DropDownList;
                for (int i = 0; i < Boxes2[currentComboBox2 - 1].Items.Count; i++)
                {
                    if (Boxes2[currentComboBox2 - 1].Items[i] != Boxes2[currentComboBox2 - 1].SelectedItem)
                        Boxes2[currentComboBox2].Items.Add(Boxes2[currentComboBox2 - 1].Items[i]);
                }
                panel4.Controls.Add(Boxes2[currentComboBox2]);
            }
            sort2 = "";
            if (Boxes2[0].SelectedItem.ToString() != "")
            {
                sort2 = "ORDER BY " + Boxes2[0].SelectedItem.ToString();
                for (int i = 1; i < Boxes2.Length; i++)
                {
                    if (Boxes2[i] != null)
                    {
                        if (Boxes2[i].SelectedItem != null && Boxes2[i].SelectedItem.ToString() !="")
                        {
                            sort2 += ", " + Boxes2[i].SelectedItem.ToString();
                        }
                        else
                            break;
                    }
                }
            }
            updateTable2();
        }

        private void cleareBoxes2(int a)
        {
            for (int i = a; i < Boxes2.Length; i++)
            {
                panel4.Controls.Remove(Boxes2[i]);
            }
        }

        private void checkedListBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            saveTable2();
            updateTable2();
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            updateTable2();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == textBox8.Text && textBox7.Text == textBox6.Text && conn!=null)
            {
                MessageBox.Show("Эта таблица уже открыта");
            }
            else
            {
                connstring2 = String.Format("Server=" + textBox12.Text + ";Port=" + textBox11.Text + ";User Id=" + textBox10.Text + ";Password=" + textBox9.Text + ";Database=" + textBox8.Text + ";");
                tableName2 = Convert.ToString(textBox7.Text);
                panel3.Visible = false;
                panel4.Visible = true;
                conect2();
            }
        }

        private void conect2()
        {
            try
            {
                conn2 = new NpgsqlConnection(connstring2);
                conn2.Open();

                string sql2 = "SELECT * FROM " + tableName2;
                da21 = new NpgsqlDataAdapter(sql2, conn2);

                ds2.Reset();
                da21.Fill(ds2);
                dt21 = ds2.Tables[0];
                dataGridView2.DataSource = dt21;

                string sqlSelect = "SELECT column_name, data_type FROM INFORMATION_SCHEMA.COLUMNS WHERE table_name = '" + tableName2 + "' ";
                da22 = new NpgsqlDataAdapter(sqlSelect, conn2);
                da22.Fill(dt22);
                for (int i = 0; i < dt22.Rows.Count; i++)
                {
                    checkedListBox2.Items.Add(Convert.ToString(dt22.Rows[i][0]), true);
                    comboBox2.Items.Add(Convert.ToString(dt22.Rows[i][0]));
                }
                Boxes2 = new ComboBox[comboBox2.Items.Count];
                Boxes2[0] = comboBox2;
            }
            catch
            {
                panel4.Visible = false;
                panel3.Visible = true;
                MessageBox.Show("невозможно подключиться к базе данных проверте включен ли PostgreSQL сервер");
            }

            int count=0;
            for (int i = 0; i < dt22.Rows.Count; i++)
            {
                if (dt22.Rows[i][1].ToString() == "integer") count++;
            }
            if (count != 0)
            {
                labWhere2 = new Label[count];
                minWhere2 = new TextBox[count];
                maxWhere2 = new TextBox[count];
                count = 0;
                for (int i = 0; i < dt22.Rows.Count; i++)
                {
                    if (dt22.Rows[i][1].ToString() == "integer")
                    {
                        count++;
                        if (count == 1)
                        {
                            Label lab = new Label();
                            lab.Text = dt22.Rows[i][0].ToString();
                            lab.Location = new Point(545, 7);
                            lab.Name = "lab1";
                            lab.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(lab);
                            labWhere2[count - 1] = lab;

                            TextBox min = new TextBox();
                            min.Location = new Point(505, lab.Location.Y + 24);
                            min.Name = "min1";
                            min.Size = new System.Drawing.Size(50, 30);
                            min.TextChanged += new EventHandler(Where2);
                            min.KeyPress += new KeyPressEventHandler(onlyNumbers);
                            min.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(min);
                            minWhere2[count - 1] = min;

                            TextBox max = new TextBox();
                            max.Location = new Point(565, lab.Location.Y + 24);
                            max.Name = "max1";
                            max.Size = new System.Drawing.Size(50, 30);
                            max.TextChanged += new EventHandler(Where2);
                            max.KeyPress += new KeyPressEventHandler(onlyNumbers);
                            max.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(max);
                            maxWhere2[count - 1] = max;
                        }
                        else
                        {
                            Label lab = new Label();
                            lab.Text = dt22.Rows[i][0].ToString();
                            lab.Location = new Point(545, labWhere2[count - 2].Location.Y + 50);
                            lab.Name = "lab" + count.ToString();
                            lab.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(lab);
                            labWhere2[count - 1] = lab;

                            TextBox min = new TextBox();
                            min.Location = new Point(507, lab.Location.Y + 24);
                            min.Size = new System.Drawing.Size(50, 30);
                            min.TextChanged += new EventHandler(Where2);
                            min.KeyPress += new KeyPressEventHandler(onlyNumbers);
                            min.Name = "min" + count.ToString();
                            min.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(min);
                            minWhere2[count - 1] = min;

                            TextBox max = new TextBox();
                            max.Location = new Point(567, lab.Location.Y + 24);
                            max.Name = "max" + count.ToString();
                            max.Size = new System.Drawing.Size(50, 30);
                            max.TextChanged += new EventHandler(Where2);
                            max.KeyPress += new KeyPressEventHandler(onlyNumbers);
                            max.Anchor = (AnchorStyles.Top | AnchorStyles.Right);
                            panel4.Controls.Add(max);
                            maxWhere2[count - 1] = max;
                        }
                    }
                }
            }

            try
            {
                String pkInstalledPrinters;
                for (int i = 0; i < PrinterSettings.InstalledPrinters.Count; i++)
                {
                    pkInstalledPrinters = PrinterSettings.InstalledPrinters[i];
                    printers2.Items.Add(pkInstalledPrinters);
                }
            }
            catch
            {
                MessageBox.Show("Невозможно обноружить принтеры. Печать будет недоступна.");
                print2.Visible = false;
            }

        }

        private void Where2(object sender, EventArgs e)
        {
            where2 = "";
            for (int i = 0; i < labWhere2.Length; i++)
            {
                if (minWhere2[i].Text != "")
                {
                    if (where2 == "")
                    {
                        where2 = "WHERE " + labWhere2[i].Text + ">=" + minWhere2[i].Text;
                    }
                    else
                    {
                        where2 += "AND " + labWhere2[i].Text + ">=" + minWhere2[i].Text;
                    }
                }
                if (maxWhere2[i].Text != "")
                {
                    if (where2 == "")
                    {
                        where2 = "WHERE " + labWhere2[i].Text + "<=" + maxWhere2[i].Text;
                    }
                    else
                    {
                        where2 += "AND " + labWhere2[i].Text + "<=" + maxWhere2[i].Text;
                    }
                }
            }
            updateTable2();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            closeCon2();
        }

        private void closeCon2 ()
        {
            dt22.Clear();
            conn2.Close();
            for (int i = checkedListBox2.Items.Count - 1; i >= 0; i--)
                checkedListBox2.Items.RemoveAt(i);
            for (int i = comboBox2.Items.Count - 1; i >= 0; i--)
                comboBox2.Items.RemoveAt(i);
            panel4.Visible = false;
            panel3.Visible = true;
            conn2 = null;
        }

        private void saveTable2()
        {

            
            try
            {
                if (checkedListBox2.CheckedItems.Count == checkedListBox2.Items.Count)
                {
                    if (checkBox3.Checked == false)
                    {
                        cb12 = new NpgsqlCommandBuilder(da21);
                        da21.Update(ds2);
                    }
                    else
                    {
                        checkBox3.Checked = false;
                        cb12 = new NpgsqlCommandBuilder(da21);
                        da21.Update(ds2);
                        checkBox3.Checked = true;
                    }
                }
                else
                {
                    string sql2 = "SELECT FROM " + tableName2;
                    da21 = new NpgsqlDataAdapter(sql2, conn2);
                    ds2.Reset();
                    da21.Fill(ds2);
                    dt21 = ds2.Tables[0];
                    dataGridView2.DataSource = dt21;

                    if (checkBox3.Checked == false)
                    {
                        cb12 = new NpgsqlCommandBuilder(da21);
                        da21.Update(ds2);
                    }
                    else
                    {
                        checkBox3.Checked = false;
                        cb12 = new NpgsqlCommandBuilder(da21);
                        da21.Update(ds2);
                        checkBox3.Checked = true;
                    }
                    updateTable2();
                }


                if (checkBox3.Checked == false)
                {
                    cb12 = new NpgsqlCommandBuilder(da21);
                    da21.Update(ds2);
                }
                else
                {
                    checkBox3.Checked = false;
                    cb12 = new NpgsqlCommandBuilder(da21);
                    da21.Update(ds2);
                    checkBox3.Checked = true;
                }
            }
            catch (Exception)
            {

                MessageBox.Show("Изменения в базе данных выполнить не удалось!",
                  "Уведомление о результатах", MessageBoxButtons.OK);
            }

        }
        private string name2;
        private void button8_Click(object sender, EventArgs e)
        {
            name2 = @"..\" + log.Text + "_" + textBox8.Text + "_" + textBox7.Text + "_" + DateTime.Now.ToString(@"dd_MM_yyyy__hh_mm_ss tt");
            iTextSharp.text.Document doc = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4.Rotate());
            PdfWriter.GetInstance(doc, new FileStream( name2+ "_log.pdf", FileMode.Create, FileAccess.Write, FileShare.None));
            doc.Open();
            BaseFont baseFont = BaseFont.CreateFont("C:\\Windows\\Fonts\\arial.ttf", BaseFont.IDENTITY_H, BaseFont.NOT_EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(baseFont, iTextSharp.text.Font.DEFAULTSIZE, iTextSharp.text.Font.NORMAL);

            doc.Add(new Paragraph("В таблице " + textBox7.Text + " из базы данных " + textBox8.Text, font));

            if (checkedListBox2.CheckedItems.Count == checkedListBox2.Items.Count)
            {

                if (checkBox3.Checked == false)
                {
                    for (int i = 0; i < dataGridView2.Columns.Count; i++)
                    {
                        string text = "В колонке " + dataGridView2.Columns[i].Name;
                        string hollows = " ";
                        bool full = true;
                        int count = 0;
                        for (int i2 = 0; i2 < dataGridView2.Rows.Count - 1; i2++)
                        {
                            if (dataGridView2.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                            {
                                full = false;
                                if (count == 0)
                                    hollows += Convert.ToString(i2 + 1);
                                else
                                    hollows += ", " + Convert.ToString(i2 + 1);
                                count++;
                            }
                        }
                        if (full)
                        {
                            text += " все строки заполнены";
                        }
                        else
                        {
                            if (count == 1)
                            {
                                text += " строка " + hollows + " не заполнена";
                            }
                            else
                            {
                                text += " строки " + hollows + " не заполнены";
                            }
                        }
                        doc.Add(new Paragraph(text, font));
                    }
                }
                else
                {
                    checkBox3.Checked = false;
                    for (int i = 0; i < dataGridView2.Columns.Count; i++)
                    {
                        string text = "В колонке " + dataGridView2.Columns[i].Name;
                        string hollows = " ";
                        bool full = true;
                        int count = 0;
                        for (int i2 = 0; i2 < dataGridView2.Rows.Count - 1; i2++)
                        {
                            if (dataGridView2.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                            {
                                full = false;
                                if (count == 0)
                                    hollows += Convert.ToString(i2 + 1);
                                else
                                    hollows += ", " + Convert.ToString(i2 + 1);
                                count++;
                            }
                        }
                        if (full)
                        {
                            text += " все строки заполнены";
                        }
                        else
                        {
                            if (count == 1)
                            {
                                text += " строка " + hollows + " не заполнена";
                            }
                            else
                            {
                                text += " строки " + hollows + " не заполнены";
                            }
                        }
                        doc.Add(new Paragraph(text, font));
                    }
                    checkBox3.Checked = true;
                }
            }
            else
            {
                string sql = "SELECT * FROM " + tableName;
                da21 = new NpgsqlDataAdapter(sql, conn);
                ds2.Reset();
                da21.Fill(ds);
                dt2 = ds2.Tables[0];
                dataGridView2.DataSource = dt2;

                if (checkBox3.Checked == false)
                {
                    for (int i = 0; i < dataGridView2.Columns.Count; i++)
                    {
                        string text = "В колонке " + dataGridView2.Columns[i].Name;
                        string hollows = " ";
                        bool full = true;
                        int count = 0;
                        for (int i2 = 0; i2 < dataGridView2.Rows.Count - 1; i2++)
                        {
                            if (dataGridView2.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                            {
                                full = false;
                                if (count == 0)
                                    hollows += Convert.ToString(i2 + 1);
                                else
                                    hollows += ", " + Convert.ToString(i2 + 1);
                                count++;
                            }
                        }
                        if (full)
                        {
                            text += " все строки заполнены";
                        }
                        else
                        {
                            if (count == 1)
                            {
                                text += " строка " + hollows + " не заполнена";
                            }
                            else
                            {
                                text += " строки " + hollows + " не заполнены";
                            }
                        }
                        doc.Add(new Paragraph(text, font));
                    }
                }
                else
                {
                    checkBox3.Checked = false;
                    for (int i = 0; i < dataGridView2.Columns.Count; i++)
                    {
                        string text = "В колонке " + dataGridView2.Columns[i].Name;
                        string hollows = " ";
                        bool full = true;
                        int count = 0;
                        for (int i2 = 0; i2 < dataGridView2.Rows.Count - 1; i2++)
                        {
                            if (dataGridView2.Rows[i2].Cells[i].FormattedValue.ToString() == "")
                            {
                                full = false;
                                if (count == 0)
                                    hollows += Convert.ToString(i2 + 1);
                                else
                                    hollows += ", " + Convert.ToString(i2 + 1);
                                count++;
                            }
                        }
                        if (full)
                        {
                            text += " все строки заполнены";
                        }
                        else
                        {
                            if (count == 1)
                            {
                                text += " строка " + hollows + " не заполнена";
                            }
                            else
                            {
                                text += " строки " + hollows + " не заполнены";
                            }
                        }
                        doc.Add(new Paragraph(text, font));
                    }
                    checkBox3.Checked = true;
                }
                updateTable();
            }
            doc.Close();

            //печать документа
            if (print2.Checked == true)
            {
                if (printers2.SelectedItem != null)
                {
                    PrintDocument PD = new PrintDocument();
                    string PrinterName = printers2.SelectedItem.ToString();
                    PrinterSettings PS = new PrinterSettings();
                    PS.PrinterName = PrinterName;
                    PD.PrinterSettings = PS;
                    PD.PrintPage += new PrintPageEventHandler(PD_PrintPage2);
                    PD.Print();
                }
            }

            if (protect2.Checked == true)
            {
                using (Stream output = new FileStream(name2 + "_log_pass.pdf", FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    PdfReader reader = new PdfReader(name2 + "_log.pdf");
                    PdfEncryptor.Encrypt(reader, output, true, pass.Text, "secret", PdfWriter.ALLOW_SCREENREADERS);
                    reader.Close();
                    File.Delete(name2 + "_log.pdf");

                }
            }
        }

        private void PD_PrintPage2(object sender, PrintPageEventArgs e)
        {
            PdfReader reader = new PdfReader(name2 + "_log.pdf");

            String text = "";

            for (int page = 1; page <= reader.NumberOfPages; page++)
            {
                ITextExtractionStrategy its = new iTextSharp.text.pdf.parser.LocationTextExtractionStrategy();
                String s = PdfTextExtractor.GetTextFromPage(reader, page, its);

                s = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(s)));
                text = text + s;

            }
            reader.Close();

            System.Drawing.Font PrintFont = new System.Drawing.Font("Arial", 3, FontStyle.Regular, GraphicsUnit.Millimeter);
            e.Graphics.DrawString(text, PrintFont, Brushes.Black, new PointF(0, 0));
        }
        private void print2_CheckedChanged(object sender, EventArgs e)
        {
            if (print2.Checked == true)
                printers2.Visible = true;
            else
                printers2.Visible = false;
        }

        private void bd1_chuse_Click(object sender, EventArgs e)
        {
            if (conn==null)
            {
                panel3.Visible = false;
                panel4.Visible = false;
                panel2.Visible = true;
            }
            else
            {
                panel3.Visible = false;
                panel4.Visible = false;
                panel1.Visible = true;
            }
            bd1_choose.Enabled = false;
            bd2_choose.Enabled = true;
        }

        private void bd2_choose_Click(object sender, EventArgs e)
        {
            if (conn2 == null)
            {
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = true;
            }
            else
            {
                panel1.Visible = false;
                panel2.Visible = false;
                panel4.Visible = true;
            }
            bd1_choose.Enabled = true;
            bd2_choose.Enabled = false;
        }

         char[] line;
         string logS = "";
         string passS = "";

        private void login_Click(object sender, EventArgs e)
        {
            if (log.Text=="")
            {
                errorMes.Text = "Введите логин";
            }
            else 
            {
                if (pass.Text=="")
                {
                    errorMes.Text = "Введите пароль";
                }
                else
                {
                    errorMes.Text = "";
                    if (File.Exists(@"..\log.txt"))
                    {
                        using (StreamReader sr = new StreamReader(@"..\log.txt"))
                        {
                            while(sr.Peek() >=0 )
                            {
                                line=sr.ReadLine().ToCharArray();
                                bool ps=false;
                                logS = "";
                                passS = "";
                                for (int i = 0; i < line.Length;i++ )
                                {
                                    if (ps==false)
                                    {
                                        if (line[i] != ' ')
                                        {
                                            logS += line[i].ToString();
                                        }
                                        else
                                        {
                                            ps = true;
                                        }
                                    }
                                    else 
                                    {
                                        passS += line[i].ToString();
                                    }
                                }

                                if (log.Text == logS)
                                {
                                    if (pass.Text == passS)
                                    {
                                        panel5.Visible = false;
                                    }
                                    else
                                    {
                                        errorMes.Text = "Неправельный пароль";
                                    }
                                    break;
                                }
                                else
                                {
                                    errorMes.Text = "Неправильный логин";
                                }
                            }
                            sr.Close();
                        }
                    }
                    else
                    {
                        errorMes.Text = "Файл авторизации отсуцтвует";
                    }
                }
            }
        }

        private void butExit_Click(object sender, EventArgs e)
        {
            if (panel4.Visible == true)
            {
                closeCon2();
                saveTable2();
            }
            if (panel1.Visible == true)
            {
                saveTable();
                closeCon();
            }
            panel5.Visible = true;
            log.Text = "";
            pass.Text = "";
            errorMes.Text = "";
        }   
    }
}
